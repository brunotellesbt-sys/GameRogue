(() => {
  'use strict';

  const SAVE_KEY = 'pokelike_like_static_run_v2';
  const META_KEY = 'pokelike_like_static_meta_v2';
  const SPRITE = 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/animated/';
  const SPRITE_FALLBACK = 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/';

  const app = document.getElementById('app');
  const tpl = document.getElementById('poke-card-template');

  const TYPE_EFFECT = {
    fire:{grass:2,ice:2,bug:2,steel:2,fire:.5,water:.5,rock:.5,dragon:.5},
    water:{fire:2,ground:2,rock:2,water:.5,grass:.5,dragon:.5},
    grass:{water:2,ground:2,rock:2,fire:.5,grass:.5,poison:.5,flying:.5,bug:.5,dragon:.5,steel:.5},
    electric:{water:2,flying:2,electric:.5,grass:.5,dragon:.5,ground:0},
    ice:{grass:2,ground:2,flying:2,dragon:2,fire:.5,water:.5,ice:.5,steel:.5},
    fighting:{normal:2,ice:2,rock:2,dark:2,steel:2,poison:.5,flying:.5,psychic:.5,bug:.5,fairy:.5,ghost:0},
    poison:{grass:2,fairy:2,poison:.5,ground:.5,rock:.5,ghost:.5,steel:0},
    ground:{fire:2,electric:2,poison:2,rock:2,steel:2,grass:.5,bug:.5,flying:0},
    flying:{grass:2,fighting:2,bug:2,electric:.5,rock:.5,steel:.5},
    psychic:{fighting:2,poison:2,psychic:.5,steel:.5,dark:0},
    bug:{grass:2,psychic:2,fire:.5,fighting:.5,poison:.5,flying:.5,ghost:.5,steel:.5,fairy:.5},
    rock:{fire:2,ice:2,flying:2,bug:2,fighting:.5,ground:.5,steel:.5},
    ghost:{psychic:2,ghost:2,dark:.5,normal:0},
    dragon:{dragon:2,steel:.5,fairy:0},
    steel:{ice:2,rock:2,fairy:2,fire:.5,water:.5,electric:.5,steel:.5},
    fairy:{fighting:2,dragon:2,fire:.5,poison:.5,steel:.5},
    normal:{rock:.5,ghost:0,steel:.5}
  };

  const POKEMON = [
    {id:1,name:'Bulbasaur',types:['grass','poison'],hp:45,atk:49,def:49,spd:45,evo:{level:16,to:2}},
    {id:2,name:'Ivysaur',types:['grass','poison'],hp:60,atk:62,def:63,spd:60,evo:{level:32,to:3}},
    {id:3,name:'Venusaur',types:['grass','poison'],hp:80,atk:82,def:83,spd:80},
    {id:4,name:'Charmander',types:['fire'],hp:39,atk:52,def:43,spd:65,evo:{level:16,to:5}},
    {id:5,name:'Charmeleon',types:['fire'],hp:58,atk:64,def:58,spd:80,evo:{level:36,to:6}},
    {id:6,name:'Charizard',types:['fire','flying'],hp:78,atk:84,def:78,spd:100},
    {id:7,name:'Squirtle',types:['water'],hp:44,atk:48,def:65,spd:43,evo:{level:16,to:8}},
    {id:8,name:'Wartortle',types:['water'],hp:59,atk:63,def:80,spd:58,evo:{level:36,to:9}},
    {id:9,name:'Blastoise',types:['water'],hp:79,atk:83,def:100,spd:78},
    {id:10,name:'Caterpie',types:['bug'],hp:45,atk:30,def:35,spd:45,evo:{level:7,to:11}},
    {id:12,name:'Butterfree',types:['bug','flying'],hp:60,atk:45,def:50,spd:70},
    {id:16,name:'Pidgey',types:['normal','flying'],hp:40,atk:45,def:40,spd:56,evo:{level:18,to:17}},
    {id:17,name:'Pidgeotto',types:['normal','flying'],hp:63,atk:60,def:55,spd:71,evo:{level:36,to:18}},
    {id:18,name:'Pidgeot',types:['normal','flying'],hp:83,atk:80,def:75,spd:101},
    {id:19,name:'Rattata',types:['normal'],hp:30,atk:56,def:35,spd:72,evo:{level:20,to:20}},
    {id:20,name:'Raticate',types:['normal'],hp:55,atk:81,def:60,spd:97},
    {id:21,name:'Spearow',types:['normal','flying'],hp:40,atk:60,def:30,spd:70,evo:{level:20,to:22}},
    {id:22,name:'Fearow',types:['normal','flying'],hp:65,atk:90,def:65,spd:100},
    {id:23,name:'Ekans',types:['poison'],hp:35,atk:60,def:44,spd:55,evo:{level:22,to:24}},
    {id:24,name:'Arbok',types:['poison'],hp:60,atk:95,def:69,spd:80},
    {id:25,name:'Pikachu',types:['electric'],hp:35,atk:55,def:40,spd:90,evo:{level:26,to:26}},
    {id:26,name:'Raichu',types:['electric'],hp:60,atk:90,def:55,spd:110},
    {id:27,name:'Sandshrew',types:['ground'],hp:50,atk:75,def:85,spd:40,evo:{level:22,to:28}},
    {id:28,name:'Sandslash',types:['ground'],hp:75,atk:100,def:110,spd:65},
    {id:29,name:'Nidoran♀',types:['poison'],hp:55,atk:47,def:52,spd:41,evo:{level:16,to:30}},
    {id:31,name:'Nidoqueen',types:['poison','ground'],hp:90,atk:92,def:87,spd:76},
    {id:32,name:'Nidoran♂',types:['poison'],hp:46,atk:57,def:40,spd:50,evo:{level:16,to:33}},
    {id:34,name:'Nidoking',types:['poison','ground'],hp:81,atk:102,def:77,spd:85},
    {id:35,name:'Clefairy',types:['fairy'],hp:70,atk:45,def:48,spd:35,evo:{level:28,to:36}},
    {id:36,name:'Clefable',types:['fairy'],hp:95,atk:70,def:73,spd:60},
    {id:37,name:'Vulpix',types:['fire'],hp:38,atk:41,def:40,spd:65,evo:{level:28,to:38}},
    {id:38,name:'Ninetales',types:['fire'],hp:73,atk:76,def:75,spd:100},
    {id:39,name:'Jigglypuff',types:['normal','fairy'],hp:115,atk:45,def:20,spd:20,evo:{level:28,to:40}},
    {id:40,name:'Wigglytuff',types:['normal','fairy'],hp:140,atk:70,def:45,spd:45},
    {id:41,name:'Zubat',types:['poison','flying'],hp:40,atk:45,def:35,spd:55,evo:{level:22,to:42}},
    {id:42,name:'Golbat',types:['poison','flying'],hp:75,atk:80,def:70,spd:90},
    {id:43,name:'Oddish',types:['grass','poison'],hp:45,atk:50,def:55,spd:30,evo:{level:21,to:44}},
    {id:45,name:'Vileplume',types:['grass','poison'],hp:75,atk:80,def:85,spd:50},
    {id:48,name:'Venonat',types:['bug','poison'],hp:60,atk:55,def:50,spd:45,evo:{level:31,to:49}},
    {id:49,name:'Venomoth',types:['bug','poison'],hp:70,atk:65,def:60,spd:90},
    {id:50,name:'Diglett',types:['ground'],hp:10,atk:55,def:25,spd:95,evo:{level:26,to:51}},
    {id:51,name:'Dugtrio',types:['ground'],hp:35,atk:100,def:50,spd:120},
    {id:52,name:'Meowth',types:['normal'],hp:40,atk:45,def:35,spd:90,evo:{level:28,to:53}},
    {id:53,name:'Persian',types:['normal'],hp:65,atk:70,def:60,spd:115},
    {id:54,name:'Psyduck',types:['water'],hp:50,atk:52,def:48,spd:55,evo:{level:33,to:55}},
    {id:55,name:'Golduck',types:['water'],hp:80,atk:82,def:78,spd:85},
    {id:56,name:'Mankey',types:['fighting'],hp:40,atk:80,def:35,spd:70,evo:{level:28,to:57}},
    {id:57,name:'Primeape',types:['fighting'],hp:65,atk:105,def:60,spd:95},
    {id:58,name:'Growlithe',types:['fire'],hp:55,atk:70,def:45,spd:60,evo:{level:32,to:59}},
    {id:59,name:'Arcanine',types:['fire'],hp:90,atk:110,def:80,spd:95},
    {id:60,name:'Poliwag',types:['water'],hp:40,atk:50,def:40,spd:90,evo:{level:25,to:61}},
    {id:62,name:'Poliwrath',types:['water','fighting'],hp:90,atk:95,def:95,spd:70},
    {id:63,name:'Abra',types:['psychic'],hp:25,atk:20,def:15,spd:90,evo:{level:16,to:64}},
    {id:65,name:'Alakazam',types:['psychic'],hp:55,atk:50,def:45,spd:120},
    {id:66,name:'Machop',types:['fighting'],hp:70,atk:80,def:50,spd:35,evo:{level:28,to:67}},
    {id:68,name:'Machamp',types:['fighting'],hp:90,atk:130,def:80,spd:55},
    {id:69,name:'Bellsprout',types:['grass','poison'],hp:50,atk:75,def:35,spd:40,evo:{level:21,to:70}},
    {id:71,name:'Victreebel',types:['grass','poison'],hp:80,atk:105,def:65,spd:70},
    {id:72,name:'Tentacool',types:['water','poison'],hp:40,atk:40,def:35,spd:70,evo:{level:30,to:73}},
    {id:73,name:'Tentacruel',types:['water','poison'],hp:80,atk:70,def:65,spd:100},
    {id:74,name:'Geodude',types:['rock','ground'],hp:40,atk:80,def:100,spd:20,evo:{level:25,to:75}},
    {id:76,name:'Golem',types:['rock','ground'],hp:80,atk:120,def:130,spd:45},
    {id:79,name:'Slowpoke',types:['water','psychic'],hp:90,atk:65,def:65,spd:15,evo:{level:37,to:80}},
    {id:80,name:'Slowbro',types:['water','psychic'],hp:95,atk:75,def:110,spd:30},
    {id:81,name:'Magnemite',types:['electric','steel'],hp:25,atk:35,def:70,spd:45,evo:{level:30,to:82}},
    {id:82,name:'Magneton',types:['electric','steel'],hp:50,atk:60,def:95,spd:70},
    {id:92,name:'Gastly',types:['ghost','poison'],hp:30,atk:35,def:30,spd:80,evo:{level:25,to:93}},
    {id:94,name:'Gengar',types:['ghost','poison'],hp:60,atk:65,def:60,spd:110},
    {id:95,name:'Onix',types:['rock','ground'],hp:35,atk:45,def:160,spd:70},
    {id:102,name:'Exeggcute',types:['grass','psychic'],hp:60,atk:40,def:80,spd:40,evo:{level:30,to:103}},
    {id:103,name:'Exeggutor',types:['grass','psychic'],hp:95,atk:95,def:85,spd:55},
    {id:104,name:'Cubone',types:['ground'],hp:50,atk:50,def:95,spd:35,evo:{level:28,to:105}},
    {id:105,name:'Marowak',types:['ground'],hp:60,atk:80,def:110,spd:45},
    {id:113,name:'Chansey',types:['normal'],hp:250,atk:5,def:5,spd:50},
    {id:120,name:'Staryu',types:['water'],hp:30,atk:45,def:55,spd:85,evo:{level:30,to:121}},
    {id:121,name:'Starmie',types:['water','psychic'],hp:60,atk:75,def:85,spd:115},
    {id:123,name:'Scyther',types:['bug','flying'],hp:70,atk:110,def:80,spd:105},
    {id:124,name:'Jynx',types:['ice','psychic'],hp:65,atk:50,def:35,spd:95},
    {id:125,name:'Electabuzz',types:['electric'],hp:65,atk:83,def:57,spd:105},
    {id:126,name:'Magmar',types:['fire'],hp:65,atk:95,def:57,spd:93},
    {id:127,name:'Pinsir',types:['bug'],hp:65,atk:125,def:100,spd:85},
    {id:130,name:'Gyarados',types:['water','flying'],hp:95,atk:125,def:79,spd:81},
    {id:131,name:'Lapras',types:['water','ice'],hp:130,atk:85,def:80,spd:60},
    {id:133,name:'Eevee',types:['normal'],hp:55,atk:55,def:50,spd:55,evo:{level:28,to:134}},
    {id:134,name:'Vaporeon',types:['water'],hp:130,atk:65,def:60,spd:65},
    {id:135,name:'Jolteon',types:['electric'],hp:65,atk:65,def:60,spd:130},
    {id:136,name:'Flareon',types:['fire'],hp:65,atk:130,def:60,spd:65},
    {id:143,name:'Snorlax',types:['normal'],hp:160,atk:110,def:65,spd:30},
    {id:144,name:'Articuno',types:['ice','flying'],hp:90,atk:85,def:100,spd:85},
    {id:145,name:'Zapdos',types:['electric','flying'],hp:90,atk:90,def:85,spd:100},
    {id:146,name:'Moltres',types:['fire','flying'],hp:90,atk:100,def:90,spd:90},
    {id:149,name:'Dragonite',types:['dragon','flying'],hp:91,atk:134,def:95,spd:80},
    {id:150,name:'Mewtwo',types:['psychic'],hp:106,atk:110,def:90,spd:130},
    {id:151,name:'Mew',types:['psychic'],hp:100,atk:100,def:100,spd:100},
    {id:152,name:'Chikorita',types:['grass'],hp:45,atk:49,def:65,spd:45,evo:{level:16,to:153}},
    {id:155,name:'Cyndaquil',types:['fire'],hp:39,atk:52,def:43,spd:65,evo:{level:16,to:156}},
    {id:158,name:'Totodile',types:['water'],hp:50,atk:65,def:64,spd:43,evo:{level:16,to:159}},
    {id:172,name:'Pichu',types:['electric'],hp:20,atk:40,def:15,spd:60,evo:{level:16,to:25}},
    {id:175,name:'Togepi',types:['fairy'],hp:35,atk:20,def:65,spd:20,evo:{level:24,to:176}},
    {id:179,name:'Mareep',types:['electric'],hp:55,atk:40,def:40,spd:35,evo:{level:15,to:180}},
    {id:196,name:'Espeon',types:['psychic'],hp:65,atk:65,def:60,spd:110},
    {id:197,name:'Umbreon',types:['dark'],hp:95,atk:65,def:110,spd:65},
    {id:208,name:'Steelix',types:['steel','ground'],hp:75,atk:85,def:200,spd:30},
    {id:212,name:'Scizor',types:['bug','steel'],hp:70,atk:130,def:100,spd:65},
    {id:214,name:'Heracross',types:['bug','fighting'],hp:80,atk:125,def:75,spd:85},
    {id:230,name:'Kingdra',types:['water','dragon'],hp:75,atk:95,def:95,spd:85},
    {id:248,name:'Tyranitar',types:['rock','dark'],hp:100,atk:134,def:110,spd:61},
    {id:249,name:'Lugia',types:['psychic','flying'],hp:106,atk:90,def:130,spd:110},
    {id:250,name:'Ho-Oh',types:['fire','flying'],hp:106,atk:130,def:90,spd:90},
    {id:251,name:'Celebi',types:['psychic','grass'],hp:100,atk:100,def:100,spd:100}
  ];

  const BY_ID = Object.fromEntries(POKEMON.map(p => [p.id, p]));
  const KANTO_IDS = POKEMON.filter(p => p.id <= 151).map(p => p.id);
  const JOHTO_IDS = POKEMON.filter(p => p.id >= 152 && p.id <= 251).map(p => p.id);
  const STARTERS = {1:[1,4,7],2:[152,155,158]};
  const MAPS = [
    {name:'Pewter Gym', leader:'Brock', badge:'Boulder', boss:[74,95]},
    {name:'Cerulean Gym', leader:'Misty', badge:'Cascade', boss:[120,121]},
    {name:'Vermilion Gym', leader:'Lt. Surge', badge:'Thunder', boss:[25,26]},
    {name:'Celadon Gym', leader:'Erika', badge:'Rainbow', boss:[43,45,103]},
    {name:'Fuchsia Gym', leader:'Koga', badge:'Soul', boss:[41,42,49]},
    {name:'Saffron Gym', leader:'Sabrina', badge:'Marsh', boss:[63,65,121]},
    {name:'Cinnabar Gym', leader:'Blaine', badge:'Volcano', boss:[37,58,126]},
    {name:'Viridian Gym', leader:'Giovanni', badge:'Earth', boss:[27,34,105]}
  ];
  const TOWER = [
    {name:'Kanto', boss:'Ash Ketchum', team:[25,6,9,3,143,149]},
    {name:'Johto', boss:'Lance', team:[130,149,149,6,248,250]},
    {name:'Hoenn', boss:'Steven Stone', team:[82,208,212,130,149,151]},
    {name:'Sinnoh', boss:'Cynthia', team:[94,131,130,149,150,251]},
    {name:'Unova', boss:'N', team:[212,248,149,250,249,150]}
  ];
  const ITEMS = [
    {id:'potion',name:'Potion',desc:'Heal your team by 40 HP.',kind:'use'},
    {id:'superPotion',name:'Super Potion',desc:'Heal your team by 90 HP.',kind:'use'},
    {id:'rareCandy',name:'Rare Candy',desc:'+5 Lv to your whole team.',kind:'use'},
    {id:'xAttack',name:'X Attack',desc:'+8 ATK to your whole team.',kind:'use'},
    {id:'xDefense',name:'X Defense',desc:'+8 DEF to your whole team.',kind:'use'},
    {id:'quickClaw',name:'Quick Claw',desc:'+10 SPD to your whole team.',kind:'use'},
    {id:'leftovers',name:'Leftovers',desc:'Passive heal after each battle.',kind:'passive'},
    {id:'rockyHelmet',name:'Rocky Helmet',desc:'Deals recoil to attackers.',kind:'passive'}
  ];
  const ACH = [
    ['boulder','Boulder Basher','Clear Map 1 and defeat Brock.'],
    ['cascade','Cascade Crusher','Clear Map 2 and defeat Misty.'],
    ['thunder','Thunder Tamer','Clear Map 3 and defeat Lt. Surge.'],
    ['rainbow','Rainbow Ranger','Clear Map 4 and defeat Erika.'],
    ['soul','Soul Crusher','Clear Map 5 and defeat Koga.'],
    ['marsh','Mind Breaker','Clear Map 6 and defeat Sabrina.'],
    ['volcano','Volcano Victor','Clear Map 7 and defeat Blaine.'],
    ['earth','Earth Shaker','Clear Map 8 and defeat Giovanni.'],
    ['master','Pokemon Master','Defeat all Elite Four members and the Champion.'],
    ['trueMaster','True Master','Enable Nuzlocke Mode, then beat the game.'],
    ['one','One is Enough','Beat the game with only one Pokémon on your team.'],
    ['minimalist','Minimalist','Beat the game without using an item.'],
    ['kantoTower','Kanto Champion','Clear Stage 1 of Battle Tower.'],
    ['johtoTower','Johto Champion','Clear Stage 2 of Battle Tower.'],
    ['dex10','Gotta Catch Some','Catch 10 different Pokémon.'],
    ['shiny','Shiny Spark','Catch a shiny Pokémon.']
  ];

  const defaultMeta = () => ({wins:0,bestTower:0,pokedex:{},achievements:{},hof:[],theme:'dark'});
  const defaultRun = () => ({active:false,screen:'home',mode:'normal',gen:1,gender:null,map:0,step:0,badges:0,route:[],team:[],items:[],usedItems:0,battle:null,choices:[],lastNode:null,towerStage:null,pendingCatch:null,log:[]});
  let meta = load(META_KEY, defaultMeta());
  let state = load(SAVE_KEY, defaultRun());

  function load(key, fallback){try{return Object.assign(fallback, JSON.parse(localStorage.getItem(key)) || {});}catch{return fallback;}}
  function save(){localStorage.setItem(META_KEY, JSON.stringify(meta)); localStorage.setItem(SAVE_KEY, JSON.stringify(state));}
  function wipeRun(){state = defaultRun(); save();}
  function rand(n){return Math.floor(Math.random()*n);}
  function pick(arr){return arr[rand(arr.length)];}
  function sample(arr, n){const pool=[...arr]; const out=[]; while(pool.length && out.length<n){out.push(pool.splice(rand(pool.length),1)[0]);} return out;}
  function clamp(v,min,max){return Math.max(min, Math.min(max, v));}
  function escapeHtml(s){return String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
  function toast(msg){const el=document.createElement('div'); el.className='toast'; el.textContent=msg; document.body.appendChild(el); setTimeout(()=>el.remove(),1700);}

  function baseStat(base, level, bonus=0){return Math.max(1, Math.floor(base + level*1.65 + bonus));}
  function makeMon(id, level=5, shiny=false){
    const p = BY_ID[id] || BY_ID[1];
    const maxHp = baseStat(p.hp, level, 20);
    return {id:p.id,name:p.name,types:p.types,level,maxHp,hp:maxHp,atk:baseStat(p.atk,level),def:baseStat(p.def,level),spd:baseStat(p.spd,level),shiny:shiny || Math.random()<0.015};
  }
  function cloneMon(mon){return JSON.parse(JSON.stringify(mon));}
  function learnDex(mon){meta.pokedex[mon.id] = meta.pokedex[mon.id] || {caught:false,shiny:false}; meta.pokedex[mon.id].caught = true; if(mon.shiny) meta.pokedex[mon.id].shiny = true;}
  function alive(team){return team.find(m => m.hp > 0);}
  function healTeam(amount=9999){state.team.forEach(m => {m.hp = clamp(m.hp + amount, 0, m.maxHp);});}
  function fullHeal(){state.team.forEach(m => m.hp = m.maxHp);}

  function screenWrap(inner, cls='screen'){
    return `<div class="${cls}">${inner}</div>`;
  }
  function nav(){
    return `<div class="topbar">
      <div class="left"><button class="small-btn clear" data-action="home">← Menu</button><button class="small-btn clear" data-action="saveCode">☁ Save Code</button></div>
      <div class="mini-logo"><h1>POKELIKE</h1><p>Pokemon Roguelike</p></div>
      <div class="right"><button class="small-btn clear" data-action="pokedex">Pokédex</button><button class="small-btn clear" data-action="achievements">Achievements</button><button class="small-btn clear" data-action="settings">⚙️</button></div>
    </div>`;
  }
  function setScreen(s){state.screen=s; save(); render();}
  function render(){
    document.body.dataset.theme = meta.theme;
    updateAchievements();
    const fn = {
      home:renderHome, gender:renderGender, starter:renderStarter, run:renderRun, battle:renderBattle, catch:renderCatch,
      item:renderItem, trade:renderTrade, teamFull:renderTeamFull, badge:renderBadge, gameover:renderGameOver, champion:renderChampion,
      pokedex:renderPokedex, achievements:renderAchievements, hof:renderHof, patch:renderPatch, settings:renderSettings,
      saveCode:renderSaveCode, tower:renderTower
    }[state.screen] || renderHome;
    app.innerHTML = fn();
    bind();
  }

  function renderHome(){
    const canContinue = state.active && state.team.length;
    return screenWrap(`<div class="menu-inner">
      <h1 class="logo">POKELIKE</h1>
      <p class="subtitle">Pokemon Roguelike</p>
      <p class="version">v1.5.1 — patch notes</p>
      <div class="top-save-row">
        <button class="small-btn clear" data-action="continueRun" ${canContinue?'':'disabled'}>Continue Run</button>
        <button class="small-btn clear" data-action="continueTower" ${meta.bestTower || meta.wins ? '' : 'disabled'}>Continue Battle Tower</button>
      </div>
      <div class="gen-row"><span class="gen-label">Gen:</span><button class="tiny-toggle ${state.gen===1?'on':''}" data-action="setGen" data-gen="1">I</button><button class="tiny-toggle ${state.gen===2?'on':''}" data-action="setGen" data-gen="2">II</button></div>
      <div class="menu-row two"><button class="primary" data-action="newRun" data-mode="normal">Normal Mode</button><button class="danger" data-action="newRun" data-mode="nuzlocke">Nuzlocke</button></div>
      <div class="menu-row full"><button data-action="tower">Battle Tower</button></div>
      <div class="menu-row two small"><button data-action="pokedex">Pokédex</button><button data-action="achievements">Achievements</button></div>
      <div class="menu-row two small"><button data-action="hof">Hall of Fame</button><button data-action="patch">Patch Notes</button></div>
      <div class="menu-row full"><button data-action="settings">⚙️ Settings</button></div>
      <div class="menu-row full"><button data-action="saveCode">☁ Save Code</button></div>
      <a class="footer-link" href="https://discord.gg/" target="_blank" rel="noreferrer">☁ Join Discord</a>
      <p class="disclaimer">Fan-made project. Not affiliated with, endorsed by, or sponsored by Nintendo, Game Freak, or The Pokémon Company.</p>
    </div>`, 'center-menu');
  }

  function renderGender(){
    return screenWrap(`${nav()}<section class="panel pad modal-like"><h2 class="title">Who are you?</h2><div class="choice-grid"><button class="trainer-choice" data-action="setGender" data-gender="boy"><span class="trainer-sprite">🧢</span><span>BOY</span></button><button class="trainer-choice" data-action="setGender" data-gender="girl"><span class="trainer-sprite">🎀</span><span>GIRL</span></button></div></section>`);
  }
  function renderStarter(){
    const ids = STARTERS[state.gen];
    return screenWrap(`${nav()}<section class="panel pad modal-like"><h2 class="title">Choose Your Starter!</h2><div class="cards">${ids.map(id => cardHTML(makeMon(id,5), 'chooseStarter')).join('')}</div><p class="subtle">Wins: ${meta.wins}</p></section>`);
  }
  function renderRun(){
    if(!state.active) return renderHome();
    const active = state.route[state.step];
    return screenWrap(`${nav()}<div class="main-grid">
      <main class="panel pad">
        <div class="map-head"><h2>Map ${state.map+1} — ${MAPS[state.map]?.name || 'Champion Road'}</h2><span>Mode: ${state.mode}</span></div>
        <div class="route">${state.route.map((n,i)=>nodeHTML(n,i,active)).join('')}</div>
        <p class="subtle">Battle Catch Item ? Heal Boss</p>
        ${active ? `<div class="menu-row full"><button class="primary" data-action="enterNode">${nodeName(active)} →</button></div>` : ''}
      </main>${sideHTML()}</div>`);
  }
  function nodeHTML(type,i,active){
    const done = i < state.step;
    const cls = ['node', done?'done':'', i===state.step?'active':'', type==='boss'?'boss':''].join(' ');
    const icons = {battle:'⚔',catch:'⬟',item:'✦',heal:'✚',trade:'⇄',mystery:'?',boss:'★'};
    return `<button class="${cls}" data-action="node" data-index="${i}" ${i===state.step?'':'disabled'}><span class="node-icon">${icons[type]}</span><span class="node-label">${nodeName(type)}</span></button>`;
  }
  function nodeName(type){return {battle:'Battle',catch:'Catch',item:'Item',heal:'Heal',trade:'Trade',mystery:'?',boss:'Boss'}[type] || type;}
  function sideHTML(){
    return `<aside class="side">
      <section class="panel pad"><h3 class="side-title">TEAM</h3><div class="list">${state.team.map((m,i)=>cardHTML(m,'team',i)).join('') || '<p class="subtle">No Pokémon.</p>'}</div></section>
      <section class="panel pad"><h3 class="side-title">ITEMS</h3><div class="list">${state.items.map((it,i)=>itemHTML(it,i)).join('') || '<p class="subtle">No items.</p>'}</div></section>
      <section class="panel pad"><h3 class="side-title">BADGES</h3><div class="badges">${Array.from({length:8},(_,i)=>`<span class="badge ${i<state.badges?'on':''}">${i<state.badges?'◆':'◇'}</span>`).join('')}</div><p class="subtle">Badges: ${state.badges}/8</p></section>
    </aside>`;
  }
  function itemHTML(it, i){const data=ITEMS.find(x=>x.id===it)||ITEMS[0]; return `<div class="item-pill"><span>${data.name}<br><span class="muted">${data.desc}</span></span><button class="small-btn" data-action="useItem" data-index="${i}">Use</button></div>`;}

  function cardHTML(mon, action='none', index=''){
    const m = mon;
    const hpPct = Math.max(0, Math.round((m.hp / m.maxHp) * 100));
    const faint = m.hp <= 0 ? 'faint' : '';
    return `<button class="poke-card ${faint}" data-action="${action}" data-id="${m.id}" data-index="${index}" type="button">
      <span class="sprite-box"><img src="${SPRITE}${m.id}.gif" onerror="this.onerror=null;this.src='${SPRITE_FALLBACK}${m.id}.png'" alt="${escapeHtml(m.name)}"></span>
      <span class="poke-info"><strong class="poke-name">${m.shiny?'✦ ':''}${escapeHtml(m.name)}</strong><span class="poke-level">Lv.${m.level} · ${m.hp}/${m.maxHp} HP</span><span class="poke-types">${m.types.map(t=>`<i class="type ${t}">${t}</i>`).join('')}</span><span class="hp ${hpPct<35?'low':hpPct<65?'mid':''}"><i style="width:${hpPct}%"></i></span><span class="poke-stats">ATK ${m.atk} DEF ${m.def} SPD ${m.spd}</span></span>
    </button>`;
  }

  function renderBattle(){
    const b = state.battle || {title:'Wild Battle!', enemy:[], log:[]};
    return screenWrap(`${nav()}<div class="battle-title-row panel pad"><h2>${escapeHtml(b.title)}</h2><div class="battle-actions"><button class="small-btn clear" data-action="skipBattle">Skip</button><button class="small-btn primary" data-action="battleRound">Continue</button></div></div><div class="battle-layout"><section class="panel pad battle-side"><h3>Your Team</h3><div class="cards">${state.team.map(m=>cardHTML(m,'none')).join('')}</div></section><section class="panel pad battle-side"><h3>Enemy</h3><div class="cards">${b.enemy.map(m=>cardHTML(m,'none')).join('')}</div></section></div><section class="panel pad" style="margin-top:12px"><div class="battle-log">${(b.log||[]).slice(-16).map(x=>`<p>${escapeHtml(x)}</p>`).join('')}</div></section>`);
  }
  function renderCatch(){
    return screenWrap(`${nav()}<section class="panel pad modal-like"><h2 class="title">⬟ Wild Pokemon Appeared!</h2><p class="subtle">Choose one Pokemon to add to your team</p><div class="cards">${state.choices.map(m=>cardHTML(m,'catchChoice')).join('')}</div><div class="menu-row full"><button class="clear" data-action="skipChoice">Skip (flee)</button></div></section>`);
  }
  function renderItem(){
    return screenWrap(`${nav()}<section class="panel pad modal-like"><h2 class="title">✦ Item Found!</h2><p class="subtle">Choose one item to keep</p><div class="choice-grid">${state.choices.map((it,i)=>`<button data-action="takeItem" data-index="${i}"><span>${ITEMS.find(x=>x.id===it).name}</span><br><span class="muted">${ITEMS.find(x=>x.id===it).desc}</span></button>`).join('')}</div><div class="menu-row full"><button class="clear" data-action="skipChoice">Skip</button></div></section>`);
  }
  function renderTrade(){
    const [give, get] = state.choices;
    return screenWrap(`${nav()}<section class="panel pad modal-like"><h2 class="title">⇄ Trade Offer</h2><p class="subtle">Give one team Pokémon for a stronger stranger.</p><div class="battle-layout"><div><h3 class="side-title">Give</h3>${give?cardHTML(give,'none'):''}</div><div><h3 class="side-title">Receive</h3>${get?cardHTML(get,'none'):''}</div></div><div class="menu-row two"><button class="primary" data-action="acceptTrade">Accept</button><button class="clear" data-action="skipChoice">Decline</button></div></section>`);
  }

  function renderTeamFull(){
    const mon = state.pendingCatch || state.choices[0];
    return screenWrap(`${nav()}<section class="panel pad modal-like"><h2 class="title">Team Full!</h2><p class="subtle">Choose one Pokémon to replace, or keep team as-is.</p><div class="battle-layout"><div><h3 class="side-title">New Pokémon</h3>${mon?cardHTML(mon,'none'):''}</div><div><h3 class="side-title">Your Team</h3><div class="cards">${state.team.map((m,i)=>cardHTML(m,'replaceTeam',i)).join('')}</div></div></div><div class="menu-row full"><button class="clear" data-action="keepTeam">Keep team as-is</button></div></section>`);
  }

  function renderBadge(){
    const map = MAPS[state.map] || MAPS[0];
    return screenWrap(`${nav()}<section class="panel pad modal-like"><h2 class="title">Badge Earned!</h2><p class="subtle">${escapeHtml(map.badge)} Badge</p><div class="badges">${Array.from({length:8},(_,i)=>`<span class="badge ${i<state.badges?'on':''}">${i<state.badges?'◆':'◇'}</span>`).join('')}</div><p class="subtle">Badges: ${state.badges}/8</p><div class="menu-row full"><button class="primary" data-action="nextMap">Next Map →</button></div></section>`);
  }
  function renderGameOver(){
    return screenWrap(`<div class="big-message"><div><h2>GAME OVER</h2><div class="menu-row two"><button class="primary" data-action="newRun" data-mode="${state.mode}">Try Again</button><button data-action="home">Menu</button></div><a class="footer-link" href="https://discord.gg/" target="_blank" rel="noreferrer">☁ Join Discord</a></div></div>`);
  }
  function renderChampion(){
    return screenWrap(`<div class="big-message"><div><h2 class="champ">YOU ARE THE<br>CHAMPION!</h2><p class="subtle">Congratulations! You defeated the Elite Four!</p><div class="cards" style="margin:14px auto;max-width:720px">${state.team.map(m=>cardHTML(m,'none')).join('')}</div><div class="menu-row three"><button class="primary" data-action="newRun" data-mode="normal">Play Again</button><button data-action="share">Share</button><button class="gold" data-action="tower">Climb the Tower</button></div><div class="menu-row full"><button data-action="hof">Hall of Fame</button></div><a class="footer-link" href="https://discord.gg/" target="_blank" rel="noreferrer">☁ Join Discord</a></div></div>`);
  }
  function renderTower(){
    const unlocked = meta.wins > 0 || meta.bestTower > 0;
    return screenWrap(`${nav()}<section class="panel pad modal-like"><h2 class="title">⚔ Battle Tower</h2><p class="subtle">${unlocked?'Choose a stage to begin':'Unlocks after a champion clear. You can still preview Stage 1 here.'}</p><div class="choice-grid">${TOWER.map((s,i)=>`<button data-action="startTower" data-index="${i}" ${!unlocked && i>0?'disabled':''}>Stage ${i+1}<br><span class="muted">${s.name} — ${s.boss}</span></button>`).join('')}</div><div class="menu-row two"><button class="clear" data-action="home">← Back</button><button data-action="share">Share</button></div></section>`);
  }
  function renderPokedex(){
    const ids = state.gen===1 ? KANTO_IDS : [...KANTO_IDS,...JOHTO_IDS];
    return screenWrap(`${nav()}<section class="panel pad"><h2 class="title">Pokédex</h2><p class="subtle">Caught: ${Object.values(meta.pokedex).filter(x=>x.caught).length}/${ids.length}</p><div class="dex-grid">${ids.map(id=>{const p=BY_ID[id]; const c=meta.pokedex[id]?.caught; return `<div class="dex-entry ${c?'caught':''}"><img src="${SPRITE_FALLBACK}${id}.png" alt="${p.name}"><span>No.${String(id).padStart(3,'0')}<br>${c?escapeHtml(p.name):'???'}</span></div>`}).join('')}</div></section>`);
  }
  function renderAchievements(){
    return screenWrap(`${nav()}<section class="panel pad modal-like"><h2 class="title">Achievements</h2><div class="achievements">${ACH.map(([id,n,d])=>`<div class="ach ${meta.achievements[id]?'done':''}"><span class="medal">${meta.achievements[id]?'🏆':'◇'}</span><span><strong>${n}</strong><br><span class="muted">${d}</span></span></div>`).join('')}</div></section>`);
  }
  function renderHof(){
    return screenWrap(`${nav()}<section class="panel pad"><h2 class="title">Hall of Fame</h2>${meta.hof.length?meta.hof.map((h,i)=>`<div class="panel pad" style="margin-bottom:10px"><h3 class="side-title">Championship #${meta.hof.length-i}</h3><p class="subtle">${h.mode} · ${h.badges} Badges · ${h.date}</p><div class="cards">${h.team.map(m=>cardHTML(m,'none')).join('')}</div></div>`).join(''):'<p class="subtle">No champion teams yet.</p>'}</section>`);
  }
  function renderPatch(){
    return screenWrap(`${nav()}<section class="panel pad modal-like patch"><h2 class="title">Patch Notes</h2><h3>v1.5.1</h3><p>Added Gen selector, Save Code, Battle Tower shortcut and closer pixel UI.</p><h3>v1.4.5</h3><p>Normal Mode, Nuzlocke, Hall of Fame, Achievements, local save and responsive mobile layouts.</p><h3>Notes</h3><p>This GitHub Pages edition is static and does not need a server/API.</p></section>`);
  }
  function renderSettings(){
    return screenWrap(`${nav()}<section class="panel pad modal-like"><h2 class="title">⚙️ Settings</h2><div class="settings-row"><button class="${meta.theme==='dark'?'primary':''}" data-action="theme" data-theme="dark">Dark</button><button class="${meta.theme==='light'?'primary':''}" data-action="theme" data-theme="light">Light</button></div><div class="settings-row"><button class="danger" data-action="resetRun">Reset Run</button><button class="danger" data-action="resetAll">Reset All Save</button></div><p class="subtle">Progress is stored with localStorage in this browser.</p></section>`);
  }
  function renderSaveCode(){
    const code = btoa(unescape(encodeURIComponent(JSON.stringify({meta,state}))));
    return screenWrap(`${nav()}<section class="panel pad modal-like save-box"><h2 class="title">☁ Save Code</h2><p class="subtle">Copy this code to move your save to another browser.</p><textarea id="saveText">${code}</textarea><div class="menu-row two"><button data-action="copySave">Copy</button><button data-action="importSave">Import from box</button></div></section>`);
  }

  function newRun(mode){
    const chosenGen = state.gen || 1;
    state = defaultRun();
    state.gen = chosenGen;
    state.active=true; state.mode=mode; state.screen='gender'; state.route=[]; state.items=[]; save(); render();
  }
  function chooseStarter(id){
    const mon = makeMon(Number(id), 5); state.team=[mon]; learnDex(mon); state.map=0; state.step=0; state.badges=0; state.route=makeRoute(); state.active=true; state.screen='run'; save(); render();
  }
  function makeRoute(){
    const pool = ['battle','catch','item','mystery','heal','trade'];
    return [pick(pool),pick(pool),pick(pool),pick(pool),'boss'];
  }
  function currentPool(){return state.gen===1 ? KANTO_IDS : [...KANTO_IDS, ...JOHTO_IDS];}
  function levelForMap(extra=0){return 5 + state.map*8 + state.step*2 + extra;}

  function enterNode(){
    const node = state.route[state.step]; state.lastNode=node;
    if(node==='battle') return startBattle('Wild Battle!', randomEnemyTeam(1 + (state.map>3?1:0), levelForMap()), 'node');
    if(node==='catch') return startCatch();
    if(node==='item') return startItem();
    if(node==='heal'){fullHeal(); toast('Team healed!'); return finishNode();}
    if(node==='trade') return startTrade();
    if(node==='mystery') return ({battle:()=>startBattle('Wild Battle!', randomEnemyTeam(1,levelForMap()),'node'), catch:startCatch, item:startItem, heal:()=>{fullHeal(); toast('Mystery heal!'); finishNode();}, trade:startTrade})[pick(['battle','catch','item','heal','trade'])]();
    if(node==='boss') return startBoss();
  }
  function randomEnemyTeam(n, level){return sample(currentPool(), n).map(id=>makeMon(id, level + rand(4)));}
  function startBoss(){
    const map = MAPS[state.map];
    const level = 12 + state.map*8;
    startBattle(`${map.leader} wants to battle!`, map.boss.map((id,i)=>makeMon(id, level + i*3)), 'boss');
  }
  function startBattle(title, enemy, source='node'){
    state.battle={title,enemy,source,log:[title]}; state.screen='battle'; save(); render();
  }
  function startCatch(){
    state.choices = sample(currentPool(),3).map(id=>makeMon(id, levelForMap(rand(5)))); state.screen='catch'; save(); render();
  }
  function startItem(){state.choices=sample(ITEMS.map(i=>i.id),3); state.screen='item'; save(); render();}
  function startTrade(){
    if(!state.team.length) return finishNode();
    const give = cloneMon(pick(state.team));
    const get = makeMon(pick(currentPool()), Math.max(give.level+6, levelForMap(5)));
    state.choices=[give,get]; state.screen='trade'; save(); render();
  }
  function finishNode(){
    state.step += 1;
    if(state.step >= state.route.length){ nextMap(); return; }
    state.screen='run'; save(); render();
  }
  function nextMap(){
    if(state.badges >= 8){winChampion(); return;}
    state.map = Math.min(7, state.map + 1); state.step=0; state.route=makeRoute(); fullHeal(); state.screen='run'; save(); render();
  }

  function battleRound(){
    const b = state.battle; if(!b) return;
    const a = alive(state.team), e = alive(b.enemy);
    if(!a) return loseGame();
    if(!e) return winBattle();
    const first = a.spd >= e.spd ? [a,e] : [e,a];
    attack(first[0], first[1], first[0]===a ? 'Your' : 'Enemy');
    if(first[1].hp > 0) attack(first[1], first[0], first[1]===a ? 'Your' : 'Enemy');
    if(!alive(state.team)) return loseGame();
    if(!alive(b.enemy)) return winBattle();
    save(); render();
  }
  function attack(att, def, side){
    const moveType = pick(att.types);
    const mult = def.types.reduce((m,t)=>m*(TYPE_EFFECT[moveType]?.[t] ?? 1),1);
    const base = Math.max(2, Math.floor((att.atk * (0.72 + Math.random()*.42)) - def.def*.33 + att.level*.9));
    const dmg = Math.max(1, Math.floor(base * mult));
    def.hp = clamp(def.hp - dmg, 0, def.maxHp);
    const eff = mult>1.1?' It is super effective!':mult<.9?' It is not very effective.':'';
    state.battle.log.push(`${side} ${att.name} used ${moveType.toUpperCase()}! ${dmg} dmg.${eff}`);
    if(def.hp<=0) state.battle.log.push(`${def.name} fainted!`);
    if(side==='Enemy' && state.items.includes('rockyHelmet')){att.hp=clamp(att.hp-6,0,att.maxHp); state.battle.log.push('Rocky Helmet dealt recoil!');}
  }
  function winBattle(){
    const source = state.battle.source;
    gainLevels(source==='boss'?5:3);
    if(state.items.includes('leftovers')) healTeam(16);
    state.battle.log.push('Victory!');
    if(source==='boss'){
      state.badges += 1;
      state.step=0;
      fullHeal();
      const ids=['boulder','cascade','thunder','rainbow','soul','marsh','volcano','earth'];
      meta.achievements[ids[state.badges-1]]=true;
      if(state.badges>=8){save(); winChampion(); return;}
      state.screen='badge'; save(); render(); return;
    }
    if(source==='tower'){
      const st = state.towerStage || 0;
      meta.bestTower = Math.max(meta.bestTower, st+1);
      meta.achievements[['kantoTower','johtoTower','hoennTower','sinnohTower','unovaTower'][st] || 'kantoTower']=true;
      toast(`Stage ${st+1} clear!`); state.screen='tower'; save(); render(); return;
    }
    finishNode();
  }
  function loseGame(){state.screen='gameover'; state.active=false; save(); render();}
  function skipBattle(){state.team.forEach(m=>m.hp=clamp(m.hp-15,0,m.maxHp)); if(!alive(state.team)) return loseGame(); finishNode();}
  function gainLevels(n){
    state.team.forEach(m=>{ if(m.hp>0){ m.level+=n; m.maxHp+=Math.floor(n*4); m.hp=clamp(m.hp+Math.floor(n*6),0,m.maxHp); m.atk+=Math.floor(n*2.1); m.def+=Math.floor(n*1.8); m.spd+=Math.floor(n*1.7); evolveIfReady(m); } });
  }
  function evolveIfReady(mon){
    const p = BY_ID[mon.id]; if(!p?.evo || mon.level < p.evo.level) return;
    const next = BY_ID[p.evo.to]; if(!next) return;
    const hpPct = mon.hp / mon.maxHp;
    mon.id = next.id; mon.name=next.name; mon.types=next.types; mon.maxHp += Math.max(8, next.hp - p.hp); mon.hp = Math.max(1, Math.floor(mon.maxHp*hpPct)); mon.atk += Math.max(4, next.atk - p.atk); mon.def += Math.max(4, next.def - p.def); mon.spd += Math.max(3, next.spd - p.spd); learnDex(mon);
  }
  function winChampion(){
    meta.wins += 1; meta.achievements.master = true; if(state.mode==='nuzlocke') meta.achievements.trueMaster = true; if(state.team.length===1) meta.achievements.one = true; if(state.usedItems===0) meta.achievements.minimalist = true;
    meta.hof.unshift({date:new Date().toLocaleDateString(),mode:state.mode,badges:state.badges,team:state.team.map(cloneMon)});
    meta.hof = meta.hof.slice(0,12); state.screen='champion'; state.active=false; save(); render();
  }
  function useItem(index){
    const it = state.items[index]; if(!it) return;
    if(it==='potion') healTeam(40); else if(it==='superPotion') healTeam(90); else if(it==='rareCandy') gainLevels(5); else if(it==='xAttack') state.team.forEach(m=>m.atk+=8); else if(it==='xDefense') state.team.forEach(m=>m.def+=8); else if(it==='quickClaw') state.team.forEach(m=>m.spd+=10); else {toast('Passive item stays active.'); return;}
    state.items.splice(index,1); state.usedItems++; toast('Item used!'); save(); render();
  }
  function takeItem(index){const id=state.choices[index]; if(id) state.items.push(id); finishNode();}
  function catchChoice(id){
    const mon = state.choices.find(m=>m.id===Number(id)); if(!mon) return;
    learnDex(mon); if(mon.shiny) meta.achievements.shiny=true;
    if(state.team.length < 6){state.team.push(mon); finishNode();}
    else { state.pendingCatch=mon; state.screen='teamFull'; save(); render(); }
  }
  function skipChoice(){finishNode();}
  function acceptTrade(){
    const [give,get] = state.choices; const idx = state.team.findIndex(m=>m.id===give.id && m.name===give.name); if(idx>=0){state.team[idx]=get; learnDex(get);} finishNode();
  }
  function startTower(index){
    const i=Number(index); const stage=TOWER[i]; const level=55+i*9; state.active=true; state.towerStage=i;
    if(!state.team.length){state.team = STARTERS[state.gen].map(id=>makeMon(id, level-8));}
    fullHeal(); startBattle(`Battle Tower Stage ${i+1}: ${stage.boss}`, stage.team.map((id,k)=>makeMon(id, level+k*2)), 'tower');
  }
  function updateAchievements(){
    if(Object.values(meta.pokedex).filter(x=>x.caught).length >= 10) meta.achievements.dex10=true;
  }
  function share(){
    const txt = `🏆 Championship #${meta.wins || 1} on Pokelike!\nMy team:\n${state.team.map(m=>`${m.name} Lv.${m.level}`).join('\n')}`;
    navigator.clipboard?.writeText(txt); toast('Share text copied!');
  }

  function bind(){
    app.querySelectorAll('[data-action]').forEach(el=>el.addEventListener('click', e=>{
      const a=el.dataset.action;
      if(a==='home'){state.screen='home'; save(); render();}
      if(a==='setGen'){state.gen=Number(el.dataset.gen); save(); render();}
      if(a==='newRun') newRun(el.dataset.mode || 'normal');
      if(a==='continueRun') setScreen('run');
      if(a==='continueTower') setScreen('tower');
      if(a==='setGender'){state.gender=el.dataset.gender; setScreen('starter');}
      if(a==='chooseStarter') chooseStarter(el.dataset.id);
      if(a==='enterNode'||a==='node') enterNode();
      if(a==='battleRound') battleRound();
      if(a==='skipBattle') skipBattle();
      if(a==='catchChoice') catchChoice(el.dataset.id);
      if(a==='takeItem') takeItem(Number(el.dataset.index));
      if(a==='skipChoice') skipChoice();
      if(a==='acceptTrade') acceptTrade();
      if(a==='replaceTeam'){state.team[Number(el.dataset.index)] = state.pendingCatch; learnDex(state.pendingCatch); state.pendingCatch=null; finishNode();}
      if(a==='keepTeam'){state.pendingCatch=null; finishNode();}
      if(a==='nextMap') nextMap();
      if(a==='useItem') useItem(Number(el.dataset.index));
      if(a==='pokedex') setScreen('pokedex');
      if(a==='achievements') setScreen('achievements');
      if(a==='hof') setScreen('hof');
      if(a==='patch') setScreen('patch');
      if(a==='settings') setScreen('settings');
      if(a==='saveCode') setScreen('saveCode');
      if(a==='tower') setScreen('tower');
      if(a==='startTower') startTower(el.dataset.index);
      if(a==='share') share();
      if(a==='theme'){meta.theme=el.dataset.theme; save(); render();}
      if(a==='resetRun'){wipeRun(); render();}
      if(a==='resetAll'){localStorage.removeItem(SAVE_KEY); localStorage.removeItem(META_KEY); meta=defaultMeta(); state=defaultRun(); render();}
      if(a==='copySave'){const t=document.getElementById('saveText'); t.select(); navigator.clipboard?.writeText(t.value); toast('Copied!');}
      if(a==='importSave'){
        try{const obj=JSON.parse(decodeURIComponent(escape(atob(document.getElementById('saveText').value.trim())))); meta=obj.meta||meta; state=obj.state||state; save(); toast('Save imported!'); render();}catch(err){toast('Invalid save code.');}
      }
    }));
  }

  render();
})();
