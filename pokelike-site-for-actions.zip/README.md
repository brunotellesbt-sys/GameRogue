# POKELIKE — GitHub Pages Edition

Versão estática em HTML/CSS/JavaScript, feita para subir direto no GitHub Pages.

## Como rodar no PC

Abra `index.html` no navegador.

## Como publicar no GitHub Pages

1. Crie um repositório público no GitHub.
2. Extraia este ZIP.
3. Envie os arquivos `index.html`, `style.css`, `game.js`, `.nojekyll` e `README.md` para a raiz do repositório.
4. Vá em **Settings > Pages**.
5. Em **Build and deployment**, selecione **Deploy from a branch**.
6. Escolha `main` e `/root`, depois clique em **Save**.

O jogo usa `localStorage` para salvar progresso no próprio navegador e carrega sprites públicos pela internet.
